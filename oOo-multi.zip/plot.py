import numpy  as np
from scipy.signal import savgol_filter
import matplotlib.pyplot as plt
import sys,os

if __name__ == '__main__':
    filename = "1.txt"
    if len(sys.argv) > 1:
            for i in range(len(sys.argv)):
                if sys.argv[1] == "-D":
                   filename = "drift.txt"
                else:
                    filename = str(sys.argv[1])+".txt"
    print("Opening :",filename)
    data = np.loadtxt("output/"+filename,dtype=str)


    x = data[:, 0]
    y = data[:, 1]
    y= ['0' if v == 'None' else v for v in y]
    x= np.asarray(x,dtype=float)
    y= np.asarray(y,dtype=float)
    y1 = savgol_filter(y, 151, 4)

    plt.plot(x, y,'k--')
    plt.plot(x,y1, 'r--')
    plt.show()
