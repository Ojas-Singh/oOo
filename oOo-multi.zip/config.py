stack_size = 200
exposure = 1000
resolution = 256
workers = 20
driftworkers = 2
qu_limit = 100
driftworker = 4